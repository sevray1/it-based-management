package at.ac.tuwien.imw.pdca;

/**
 * 
 * @author ivanstojkovic
 *
 */
public interface DoRules {
	public void applyDoRules();
}
