package at.ac.tuwien.imw.pdca;

/**
 * 
 * @author ivanstojkovic
 *
 */
public interface CheckingRules {
	public void applyCheckingRules();
}
