package at.ac.tuwien.imw.pdca;

/**
 * 
 * @author ivanstojkovic
 *
 * @param <T>
 */
public interface AdaptiveActRules {
	public void applyActRules();
}
