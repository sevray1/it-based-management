package at.ac.tuwien.imw.pdca;

/**
 * 
 * @author ivanstojkovic
 *
 * @param <T>
 */
public interface CorrectiveActRules {
	public void applyActRules();
}
