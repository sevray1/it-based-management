package at.ac.tuwien.imw.pdca;


public abstract class PlanConfiguration {
	
	private Long id;
	
	public Long getId() {
		return id;
	}
	
}
