package at.ac.tuwien.imw.pdca;

/**
 * 
 * @author ivanstojkovic
 *
 */
public interface PlanningRules<T> {
	public T applyPlanningRules();
}
