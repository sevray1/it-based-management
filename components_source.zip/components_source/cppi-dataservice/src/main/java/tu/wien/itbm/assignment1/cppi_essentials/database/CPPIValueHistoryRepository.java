package tu.wien.itbm.assignment1.cppi_essentials.database;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import tu.wien.itbm.assignment1.cppi_essentials.model.dto.CPPIValuesDTO;

public interface CPPIValueHistoryRepository extends CrudRepository<CPPIValuesDTO, Long> {
	List<CPPIValuesDTO> findAllByAccount(String account);
}
