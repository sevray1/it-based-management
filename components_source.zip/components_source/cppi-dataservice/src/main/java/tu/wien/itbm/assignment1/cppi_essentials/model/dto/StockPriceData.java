package tu.wien.itbm.assignment1.cppi_essentials.model.dto;

public class StockPriceData {
	private Double price;

	public StockPriceData() {}
	
	public StockPriceData(final Double price) {
		this.price = price;
	}
	
	public Double getPrice() {
		return price;
	}

	public void setPrice(final Double price) {
		this.price = price;
	}
}
