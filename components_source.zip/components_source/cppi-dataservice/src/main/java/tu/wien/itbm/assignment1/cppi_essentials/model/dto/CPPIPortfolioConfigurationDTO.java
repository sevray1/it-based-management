package tu.wien.itbm.assignment1.cppi_essentials.model.dto;

public class CPPIPortfolioConfigurationDTO {
	
	private Double floorObjective; 	// FT
	private Double riskAppetite; 	// m - multiplier showing risk appetite
	private Double maxRiskFraction; // b - maximum risky Fraction, stands for the limit of risky investment
	private Double investement; 	// initial investment, Wt with t = 0
	private Double timeHorizon; 	// overall investment period
	private String account; // user account;
	private Double r = 0.05; // riskless asset interest rate
	
	public CPPIPortfolioConfigurationDTO() {}

	public Double getFloorObjective() {
		return floorObjective;
	}

	public void setFloorObjective(Double floorObjective) {
		this.floorObjective = floorObjective;
	}

	public Double getRiskAppetite() {
		return riskAppetite;
	}

	public void setRiskAppetite(Double riskAppetite) {
		this.riskAppetite = riskAppetite;
	}

	public Double getMaxRiskFraction() {
		return maxRiskFraction;
	}

	public void setMaxRiskFraction(Double maxRiskFraction) {
		this.maxRiskFraction = maxRiskFraction;
	}

	public Double getInvestement() {
		return investement;
	}

	public void setInvestement(Double investement) {
		this.investement = investement;
	}

	public Double getTimeHorizon() {
		return timeHorizon;
	}

	public void setTimeHorizon(Double timeHorizon) {
		this.timeHorizon = timeHorizon;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public Double getR() {
		return r;
	}

	public void setR(Double r) {
		this.r = r;
	}
}
