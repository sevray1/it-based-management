package tu.wien.itbm.assignment1.cppi_essentials.database;

import org.springframework.data.repository.CrudRepository;

import tu.wien.itbm.assignment1.cppi_essentials.model.CPPIPortfolioConfiguration;
import tu.wien.itbm.assignment1.cppi_essentials.model.CPPIValues;

public interface CPPIValueRepository extends CrudRepository<CPPIValues, Long> {

	// find by portfolio configuration
	CPPIValues findByConf(CPPIPortfolioConfiguration conf);
    
}
