package tu.wien.itbm.assignment1.cppi_essentials.model.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import tu.wien.itbm.assignment1.cppi_essentials.model.CPPIValues;

@Entity
public class CPPIValuesDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	private Integer t; // 1,2,3,4,5,6....
	private Double TtT;
	private Double Ft;
	private Double Ct;
	private Double Xrt;
	private Double Xft;
	private Double St;
	private Double TSRt;
	private Double Wt;
	private String account;
	
	public CPPIValuesDTO() {}
	
	public CPPIValuesDTO(CPPIValues values) {
		this.t = values.getPeriod().intValue();
		this.TtT = values.getTTT();
		this.Ft = values.getFloorObjective_t();
		this.Ct = values.getCushion();
		this.Xrt = values.getPartRiskyAsset();
		this.Xft = values.getPartRisklessAsset();
		this.St = values.getStockPriceNow();
		this.TSRt = values.getTsr();
		this.Wt = values.getWealth();
		this.setAccount(values.getConf().getAccount());
	}

	public Integer getT() {
		return t;
	}

	public void setT(Integer t) {
		this.t = t;
	}

	public Double getTtT() {
		return TtT;
	}

	public void setTtT(Double ttT) {
		TtT = ttT;
	}

	public Double getFt() {
		return Ft;
	}

	public void setFt(Double ft) {
		Ft = ft;
	}

	public Double getCt() {
		return Ct;
	}

	public void setCt(Double ct) {
		Ct = ct;
	}

	public Double getXrt() {
		return Xrt;
	}

	public void setXrt(Double xrt) {
		Xrt = xrt;
	}

	public Double getXft() {
		return Xft;
	}

	public void setXft(Double xft) {
		Xft = xft;
	}

	public Double getSt() {
		return St;
	}

	public void setSt(Double st) {
		St = st;
	}

	public Double getTSRt() {
		return TSRt;
	}

	public void setTSRt(Double tSRt) {
		TSRt = tSRt;
	}

	public Double getWt() {
		return Wt;
	}

	public void setWt(Double wt) {
		Wt = wt;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}
}
