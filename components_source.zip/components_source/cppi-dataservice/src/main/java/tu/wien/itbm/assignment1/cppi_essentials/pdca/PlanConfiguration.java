package tu.wien.itbm.assignment1.cppi_essentials.pdca;


public abstract class PlanConfiguration {
	
	private Long id;
	
	public Long getId() {
		return id;
	}
	
}
