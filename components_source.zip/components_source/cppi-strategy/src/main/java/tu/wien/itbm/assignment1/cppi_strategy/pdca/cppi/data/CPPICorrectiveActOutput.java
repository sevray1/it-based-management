package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.data;

import java.math.BigDecimal;

import tu.wien.itbm.assignment1.cppi_strategy.pdca.CorrectiveActOutput;

public class CPPICorrectiveActOutput extends CorrectiveActOutput<BigDecimal> {

	public CPPICorrectiveActOutput(BigDecimal value) {
		super(value);
		// TODO Auto-generated constructor stub
	}

}
