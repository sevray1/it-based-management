package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.rules;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import tu.wien.itbm.assignment1.cppi_strategy.model.dto.InvestmentInfoDTO;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.DoRules;

/**
 * 
 * @author itbm-devs
 */
public class CPPIDoRules implements DoRules {

	private	Double Xrt;
	private Double Xft;
	private Long id;
	private String account;

	public void init(final Long id, final String account, final Double xrt, final Double xft) {
		this.Xrt = xrt;
		this.Xft = xft;
		this.id = id;
		this.account = account;
	}
	
	public void applyDoRules() {
//		System.out.println(String.format("Applied DoRules: [riskyAssets=%s; risklessAssets=%s]", Xrt, Xft));
		
		// cannot handle exceptions inside here properly, do investment in CPPIStrategy
	}
}
