package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.data;

import java.math.BigDecimal;

import tu.wien.itbm.assignment1.cppi_strategy.pdca.Deviation;

public class CPPIDeviation extends Deviation<BigDecimal> {

	public CPPIDeviation(BigDecimal value) {
		super(value);
		// TODO Auto-generated constructor stub
	}

}
