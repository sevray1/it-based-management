package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.data;

import java.math.BigDecimal;

import tu.wien.itbm.assignment1.cppi_strategy.pdca.ObjectiveSetting;

public class CPPIObjective extends ObjectiveSetting<BigDecimal> {

	public CPPIObjective(final BigDecimal value) {
		setObjectiveSetting(value);
	}
	
}
