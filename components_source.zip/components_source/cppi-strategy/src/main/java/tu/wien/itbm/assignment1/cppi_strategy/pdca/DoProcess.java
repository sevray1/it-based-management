package tu.wien.itbm.assignment1.cppi_strategy.pdca;



public abstract class DoProcess {
	
	protected DoRules doRules;
	
	public abstract void operate();

}
