package tu.wien.itbm.assignment1.cppi_strategy.pdca;

/**
 * 
 * @author ivanstojkovic
 *
 */
public interface PlanningRules<T> {
	public T applyPlanningRules();
}
