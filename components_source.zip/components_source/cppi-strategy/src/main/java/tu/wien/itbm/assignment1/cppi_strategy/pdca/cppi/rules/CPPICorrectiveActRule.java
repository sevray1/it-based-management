package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.rules;

import tu.wien.itbm.assignment1.cppi_strategy.pdca.CorrectiveActRules;

/**
 * Used to calculate Xr,t
 * 
 * @author itbm-devs
 */
public class CPPICorrectiveActRule implements CorrectiveActRules {

	private Double m;
	private Double Ct;
	private Double b;
	private Double Wt;
	
	private Double resultXrt;
	
	public void init(final Double m, final Double Ct, final Double b, final Double Wt) {
		this.m = m;
		this.Ct = Ct;
		this.b = b;
		this.Wt = Wt;
	}
	
	public void applyActRules() {
		resultXrt = Math.min((m*Ct), (b*Wt));
	}

	public Double getResultXrt() {
		return resultXrt;
	}
}
