package tu.wien.itbm.assignment1.cppi_strategy.controller;

import java.io.IOException;
import java.math.BigDecimal;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import tu.wien.itbm.assignment1.cppi_strategy.model.CPPIValues;
import tu.wien.itbm.assignment1.cppi_strategy.model.dto.InvestmentInfoDTO;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.Deviation;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.CPPIActProcess;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.CPPICheckProcess;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.CPPIDoProcess;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.CPPIPlanProcess;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.data.CPPIObjective;

@Component
public class CPPIStrategy {
	
	public void receive(String message) throws JsonParseException, JsonMappingException, IOException {
		StopWatch watch = new StopWatch();
		watch.start();

		ObjectMapper mapper = new ObjectMapper();
		CPPIValues cppiValues = mapper.readValue(message, CPPIValues.class);

		// set period accordingly
		if (cppiValues.getPeriod() != null) {
			cppiValues.setPeriod(cppiValues.getPeriod() + 1);
		} else {
			cppiValues.setPeriod(0d);
		}
		// adjust the assets (set current ones to null, and previous ones to
		// current ones)
		cppiValues.correctAssets();

		// Plan - set the objective floor value
		CPPIPlanProcess planProcess = new CPPIPlanProcess();
		planProcess.setCppiValues(cppiValues);
		planProcess.plan();
		cppiValues = planProcess.getCppiValues();
		CPPIObjective objective = new CPPIObjective(new BigDecimal(cppiValues.getFloorObjective_t()));

		// Do - measuring &
		// Check - calculate the cushion
		CPPICheckProcess checkProcess = new CPPICheckProcess();
		checkProcess.setCppiValues(cppiValues);
		checkProcess.setObjective(objective);
		Deviation<BigDecimal> deviation = checkProcess.check();
		cppiValues = checkProcess.getCppiValues();

		// Act
		CPPIActProcess actProcess = new CPPIActProcess();
		actProcess.setCppiValues(cppiValues);
		actProcess.act(deviation);
		cppiValues = actProcess.getCppiValues();

		//////////////
		// DO - Business Activities (acutal investment)
		CPPIDoProcess doProcess = new CPPIDoProcess();
		doProcess.setCppiValues(cppiValues);
		doProcess.operate();
		doInvestment(cppiValues);
		
		// update/persist optimized cppi values
		returnOptimizedCPPI(cppiValues);
		
		watch.stop();
		System.out.println("Finished CPPIStrategy Optimization in " + watch.getTotalTimeSeconds() + "s");
	}
	
	private void doInvestment(CPPIValues cppiValues) throws JsonProcessingException {
		
//		System.out.println(cppiValues.getConf().toString());
		
		InvestmentInfoDTO investDTO = new InvestmentInfoDTO(
				cppiValues.getConf().getAccount(), 
				cppiValues.getId(), 
				cppiValues.getPartRiskyAsset(), 
				cppiValues.getPartRisklessAsset()
				);
		
		// call optimization interface of CPPIStrategy
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(investDTO);

		// set your headers
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		// set your entity to send
		@SuppressWarnings("unchecked")
		HttpEntity entity = new HttpEntity(jsonInString, headers);

		// send it!
		String url = "http://localhost:8090/rest/invest";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> out = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
		
//		System.out.println("Invested.");
	}
	
	private void returnOptimizedCPPI(CPPIValues cppiValues) throws JsonProcessingException {

		// call optimization interface of CPPIStrategy
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(cppiValues);

		// set your headers
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		// set your entity to send
		@SuppressWarnings("unchecked")
		HttpEntity entity = new HttpEntity(jsonInString, headers);

		// send it!
		String url = "http://localhost:8080/rest/data/cppi/update";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> out = restTemplate.exchange(url, HttpMethod.POST, entity, String.class);
		
//		System.out.println("Sent cppi values for update.");
	}

}
