package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.data;

import java.math.BigDecimal;

import tu.wien.itbm.assignment1.cppi_strategy.pdca.MeasuredPerformanceValue;

public class CPPIPerformanceMeasure extends MeasuredPerformanceValue<BigDecimal> {

	public CPPIPerformanceMeasure(BigDecimal value) {
		super(value);
		// TODO Auto-generated constructor stub
	}

}
