package tu.wien.itbm.assignment1.cppi_strategy.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import tu.wien.itbm.assignment1.cppi_strategy.model.dto.CPPIPortfolioConfigurationDTO;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.PlanConfiguration;

public class CPPIPortfolioConfiguration extends PlanConfiguration {
	
	private Long portfolioId;
	
	private Double floorObjective; 	// FT
	private Double riskAppetite; 	// m - multiplier showing risk appetite
	private Double maxRiskFraction; // b - maximum risky Fraction, stands for the limit of risky investment
	private Double investement; 	// initial investment, Wt with t = 0
	private Double timeHorizon; 	// overall investment period
	
	private String account; // user account;
	
	@JsonIgnore // otherwise circle when building json string
	private CPPIValues cppiValues;
//	
//	// not set by the user, internal value
	private Double r = 0.05; // riskless asset interest rate

	public CPPIPortfolioConfiguration() {}

	public CPPIPortfolioConfiguration(CPPIPortfolioConfigurationDTO c) {
		this.floorObjective = c.getFloorObjective();
		this.riskAppetite = c.getRiskAppetite();
		this.maxRiskFraction = c.getMaxRiskFraction();
		this.investement = c.getInvestement();
		this.timeHorizon = c.getTimeHorizon();
		this.account = c.getAccount();
	}
	
	@JsonIgnore
	public String toString() {
		
		return String.format("CPPIPortfolioConfiguration["
				+ "id=%d;"
				+ "Ft=%s;"
				+ "m=%s;"
				+ "b=%s"
				+ "invest=%s;"
				+ "time=%s;"
				+ "account=%s;"
				+ "r=%s]", 
				portfolioId,
				floorObjective,
				riskAppetite,
				maxRiskFraction,
				investement,
				timeHorizon,
				account,
				r 
		);
	}

	public Double getFloorObjective() {
		return floorObjective;
	}

	public void setFloorObjective(Double floorObjective) {
		this.floorObjective = floorObjective;
	}

	public Double getRiskAppetite() {
		return riskAppetite;
	}

	public void setRiskAppetite(Double riskAppetite) {
		this.riskAppetite = riskAppetite;
	}

	public Double getMaxRiskFraction() {
		return maxRiskFraction;
	}

	public void setMaxRiskFraction(Double maxRiskFraction) {
		this.maxRiskFraction = maxRiskFraction;
	}

	public Double getInvestement() {
		return investement;
	}

	public void setInvestement(Double investement) {
		this.investement = investement;
	}

	public Double getTimeHorizon() {
		return timeHorizon;
	}

	public void setTimeHorizon(Double timeHorizon) {
		this.timeHorizon = timeHorizon;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public Double getR() {
		return r;
	}

	public void setR(Double r) {
		this.r = r;
	}

	public CPPIValues getCppiValues() {
		return cppiValues;
	}

	public void setCppiValues(CPPIValues cppiValues) {
		this.cppiValues = cppiValues;
	}

	public Long getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(Long portfolioId) {
		this.portfolioId = portfolioId;
	}
}
