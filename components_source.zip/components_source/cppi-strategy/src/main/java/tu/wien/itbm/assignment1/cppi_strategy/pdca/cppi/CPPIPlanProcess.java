package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi;

import tu.wien.itbm.assignment1.cppi_strategy.model.CPPIValues;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.PlanProcess;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.rules.CPPIPlanRules;

/**
 * 
 * @author itbm-devs
 */
public class CPPIPlanProcess extends PlanProcess<Double> {
	
	private CPPIValues cppiValues;
	
	@Override
	public void plan() {

		CPPIPlanRules planRules = new CPPIPlanRules();

		Double floorT = cppiValues.getConf().getFloorObjective();
		Double r = cppiValues.getConf().getR();
		Double i = cppiValues.getConf().getTimeHorizon();
		Double period = cppiValues.getPeriod();
		
		planRules.init(floorT, r, i, period);
		Double Ft = planRules.applyPlanningRules();
		cppiValues.setFloorObjective_t(Ft);
	}

	public CPPIValues getCppiValues() {
		return cppiValues;
	}

	public void setCppiValues(CPPIValues cppiValues) {
		this.cppiValues = cppiValues;
	}
}
