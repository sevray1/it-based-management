package tu.wien.itbm.assignment1.cppi_strategy.pdca;

/**
 * 
 * @author ivanstojkovic
 *
 * @param <T>
 */
public interface CorrectiveActRules {
	public void applyActRules();
}
