package tu.wien.itbm.assignment1.cppi_strategy.pdca;



public abstract class PlanProcess<T> {
	
	protected PlanningRules<T> planningRules;
	
	public abstract void plan();

}
