package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.rules;

import tu.wien.itbm.assignment1.cppi_strategy.pdca.PlanningRules;

/**
 * Calculate Ft, the floor at time t
 * 
 * itbm-devs
 */
public class CPPIPlanRules implements PlanningRules<Double> {

	private Double FT;
	private Double Rt;
	private Double investmentPeriod;
	private Double currentPeriod;
	
	public void init(Double floorT, Double r, Double i, Double period) {
		// TODO Auto-generated method stub
		
		this.FT = floorT;
		this.Rt = r;
		this.investmentPeriod = i;
		this.currentPeriod = period;
	}
	
	public Double applyPlanningRules() {
		Double ttt = new Double(1)-currentPeriod/investmentPeriod;
		Double divisor = Math.pow(1+Rt, ttt);
		return (FT / divisor);
	}
}
