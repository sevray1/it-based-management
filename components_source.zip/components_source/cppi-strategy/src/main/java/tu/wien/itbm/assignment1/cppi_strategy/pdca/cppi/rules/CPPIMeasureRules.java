package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.rules;

import java.math.BigDecimal;

import tu.wien.itbm.assignment1.cppi_strategy.pdca.MeasureRules;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.MeasuredPerformanceValue;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.data.CPPIPerformanceMeasure;

public class CPPIMeasureRules implements MeasureRules<BigDecimal> {

	private Double resultTSR;
	private Double resultWealth;

	private Double Rt;
	private Double investmentPeriod;
	private Double wealth_tzero;
	private Double wealth;
	
	private Double scurrent;
	private Double sprev;
	private	Double xrprev;
	private Double xfprev;

	public void init(Double Rt, Double i,
			Double scurrent, Double sprev,
			Double xrprev, Double xfprev,
			Double wealth_tzero) {
		
		this.Rt = Rt;
		this.investmentPeriod = i;
		this.scurrent = scurrent;
		this.sprev = sprev;
		this.xrprev = xrprev;
		this.xfprev = xfprev;
		
		this.wealth_tzero = wealth_tzero;
	}
	
	public MeasuredPerformanceValue<BigDecimal> measure() {
		Double TSR;
		if (sprev != null) {
			TSR = (scurrent / sprev)-1;
			setResultTSR(TSR);			
		} else {
			TSR = Rt;
			setResultTSR(TSR);	
		}
	
		if (xrprev != null) {
			Double base = (1+Rt);
			Double risky = xrprev*(1+TSR);
			Double riskless = xfprev*((Math.pow(base, (1/investmentPeriod))));
			setResultWealth(risky + riskless);
//			System.out.println(getResultWealth());
		} else {
			setResultWealth(wealth_tzero);
		}
		
		return new CPPIPerformanceMeasure(new BigDecimal(getResultWealth()));
	}

	public Double getResultTSR() {
		return resultTSR;
	}

	public void setResultTSR(Double resultTSR) {
		this.resultTSR = resultTSR;
	}

	public Double getResultWealth() {
		return resultWealth;
	}

	public void setResultWealth(Double resultWealth) {
		this.resultWealth = resultWealth;
	}
}
