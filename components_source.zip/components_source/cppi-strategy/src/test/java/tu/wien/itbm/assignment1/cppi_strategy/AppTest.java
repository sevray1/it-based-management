package tu.wien.itbm.assignment1.cppi_strategy;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import tu.wien.itbm.assignment1.cppi_strategy.model.CPPIPortfolioConfiguration;
import tu.wien.itbm.assignment1.cppi_strategy.model.CPPIValues;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.Deviation;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.CPPIActProcess;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.CPPICheckProcess;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.CPPIDoProcess;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.CPPIPlanProcess;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.data.CPPIObjective;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }

    public CPPIValues getTestValues() {
		CPPIValues cppiValues = new CPPIValues();

		CPPIPortfolioConfiguration conf = new CPPIPortfolioConfiguration();
		conf.setFloorObjective(100d);
		conf.setTimeHorizon(365d);
		conf.setInvestement(100d);
		conf.setMaxRiskFraction(0.9d);
		conf.setRiskAppetite(2d);
		conf.setAccount("itbm-devs");
		cppiValues.setConf(conf);

		return cppiValues;
	}

	public void testCPPIStrategy() {

		CPPIValues cppiValues = getTestValues();

		// TODO: Async: call CPPIDataService to update the values
		List<Double> stockPrices = Arrays.asList(100d, 105d, 103d, 96d, 93d, 97d, 103d, 108d, 112d, 100d, 104d);

		System.out.println(cppiValues.printHeader());
		for (Double stockp : stockPrices) {
			if (cppiValues.getPeriod() != null) {
				cppiValues.setPeriod(cppiValues.getPeriod() + 1);
			} else {
				cppiValues.setPeriod(0d);
			}
			cppiValues.adjustStock(stockp);
			cppiValues.correctAssets();

			// Plan - set the objective floor value
			CPPIPlanProcess planProcess = new CPPIPlanProcess();
			planProcess.setCppiValues(cppiValues);
			planProcess.plan();
			cppiValues = planProcess.getCppiValues();
			CPPIObjective objective = new CPPIObjective(new BigDecimal(cppiValues.getFloorObjective_t()));

			// Do - measuring &
			// Check - calculate the cushion
			CPPICheckProcess checkProcess = new CPPICheckProcess();
			checkProcess.setCppiValues(cppiValues);
			checkProcess.setObjective(objective);
			Deviation<BigDecimal> deviation = checkProcess.check();
			cppiValues = checkProcess.getCppiValues();

			// Act
			CPPIActProcess actProcess = new CPPIActProcess();
			actProcess.setCppiValues(cppiValues);
			actProcess.act(deviation);
			cppiValues = actProcess.getCppiValues();

			//////////////
			// DO - Business Activities (acutal investment)
			CPPIDoProcess doProcess = new CPPIDoProcess();
			doProcess.setCppiValues(cppiValues);
//			doProcess.operate();
			
			System.out.println(cppiValues.toString());
		}

		assertTrue(true);

	}
}
