package tu.wien.itbm.assignment1.cppi_strategy.pdca;

/**
 * 
 * @author ivanstojkovic
 *
 */
public interface CheckingRules {
	public void applyCheckingRules();
}
