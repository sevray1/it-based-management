package tu.wien.itbm.assignment1.cppi_strategy.pdca;

/**
 * 
 * @author ivanstojkovic
 *
 */
public interface DoRules {
	public void applyDoRules();
}
