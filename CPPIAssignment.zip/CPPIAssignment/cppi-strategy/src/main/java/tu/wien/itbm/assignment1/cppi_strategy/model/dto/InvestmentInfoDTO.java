package tu.wien.itbm.assignment1.cppi_strategy.model.dto;

public class InvestmentInfoDTO {
	private String account;
	private Long portfolioId;
	private Double risky;
	private Double riskless;
	
	public InvestmentInfoDTO(){}
	
	public InvestmentInfoDTO(final String account, final Long id, final Double risky, final Double riskless) {
		this.risky = risky;
		this.riskless = riskless;
		this.account = account;
		this.portfolioId = id;
	}
	
	public Double getRisky() {
		return risky;
	}
	public void setRisky(final Double risky) {
		this.risky = risky;
	}
	public Double getRiskless() {
		return riskless;
	}
	public void setRiskless(final Double riskless) {
		this.riskless = riskless;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public Long getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(Long portfolioId) {
		this.portfolioId = portfolioId;
	}
	
}
