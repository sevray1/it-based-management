package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi;

import tu.wien.itbm.assignment1.cppi_strategy.model.CPPIValues;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.DoProcess;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.rules.CPPIDoRules;

/**
 * Do the calculation of the present value of the floor (Ft) Do the measuring
 * (calculation of TSR & Wt)
 * 
 * @author itbm-devs
 */
public class CPPIDoProcess extends DoProcess {

	private CPPIValues cppiValues;

	@Override
	public void operate() {

		CPPIDoRules doRules = new CPPIDoRules();

		doRules.init(cppiValues.getId(), cppiValues.getConf().getAccount(), cppiValues.getPartRiskyAsset(), cppiValues.getPartRisklessAsset());
		doRules.applyDoRules();
	}

	public CPPIValues getCppiValues() {
		return cppiValues;
	}

	public void setCppiValues(CPPIValues cppiValues) {
		this.cppiValues = cppiValues;
	}
}
