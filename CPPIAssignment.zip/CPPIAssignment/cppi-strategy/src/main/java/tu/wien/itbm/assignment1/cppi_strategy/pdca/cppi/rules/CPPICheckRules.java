package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.rules;

import java.math.BigDecimal;

import tu.wien.itbm.assignment1.cppi_strategy.pdca.CheckingRules;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.MeasuredPerformanceValue;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.ObjectiveSetting;

public class CPPICheckRules implements CheckingRules {

	private Double cushion;
	
	private Double Ft;
	private Double Wt;
	
	public void init(ObjectiveSetting<BigDecimal> objective,
			MeasuredPerformanceValue<BigDecimal> performanceMeasureValue) {
		this.Ft = objective.getObjectiveSetting().doubleValue();
		this.Wt = performanceMeasureValue.getValue().doubleValue();
		
//		System.out.println("Ft: "+ Ft);
//		System.out.println("Wt: "+ Wt);
	}
	
	public void applyCheckingRules() {
		cushion = Math.max((Wt - Ft), 0d);
//		System.out.println("Ct: " + cushion);
	}

	public Double getCushion() {
		return cushion;
	}

	public void setCushion(Double cushion) {
		this.cushion = cushion;
	}

}
