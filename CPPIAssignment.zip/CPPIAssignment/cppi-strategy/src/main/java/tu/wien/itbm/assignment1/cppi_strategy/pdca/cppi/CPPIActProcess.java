package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi;

import java.math.BigDecimal;

import tu.wien.itbm.assignment1.cppi_strategy.model.CPPIValues;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.ActProcess;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.CorrectiveActOutput;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.Deviation;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.data.CPPICorrectiveActOutput;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.rules.CPPICorrectiveActRule;

public class CPPIActProcess extends ActProcess<BigDecimal, BigDecimal> {

	private CPPIValues cppiValues;

	@Override
	public CorrectiveActOutput<BigDecimal> act(Deviation<BigDecimal> deviation) {

		CPPICorrectiveActRule actRule = new CPPICorrectiveActRule();
		actRule.init(cppiValues.getConf().getRiskAppetite(), deviation.getValue().doubleValue(),
				cppiValues.getConf().getMaxRiskFraction(), cppiValues.getWealth());
		actRule.applyActRules();

		CPPICorrectiveActOutput correctiveAct = new CPPICorrectiveActOutput( new BigDecimal(actRule.getResultXrt()) );
		
		// based on the correctiveAct calculate the risklessAsset amount
		Double Xft = cppiValues.getWealth()-correctiveAct.getValue().doubleValue();
		Double Xrt = actRule.getResultXrt();
		
		cppiValues.setPartRiskyAsset(Xrt);
		cppiValues.setPartRisklessAsset(Xft);
		
		// won't be used in outer method, everything done inside here.
		// corrective values are already set via the correct Assets Method
		return correctiveAct;
	}

	public CPPIValues getCppiValues() {
		return cppiValues;
	}

	public void setCppiValues(CPPIValues cppiValues) {
		this.cppiValues = cppiValues;
	}

}
