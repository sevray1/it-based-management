package tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi;

import java.math.BigDecimal;

import tu.wien.itbm.assignment1.cppi_strategy.model.CPPIValues;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.CheckProcess;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.Deviation;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.MeasuredPerformanceValue;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.ObjectiveSetting;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.data.CPPIDeviation;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.rules.CPPICheckRules;
import tu.wien.itbm.assignment1.cppi_strategy.pdca.cppi.rules.CPPIMeasureRules;

public class CPPICheckProcess extends CheckProcess<BigDecimal> {

	private CPPIValues cppiValues;
	private ObjectiveSetting<BigDecimal> objective;
	
	/**
	 * Return the cushion afterwards the risky and riskless assets will be calculated
	 * based on that value in the ActProcess
	 * 
	 */
	@Override
	public Deviation<BigDecimal> getCheckResult(ObjectiveSetting<BigDecimal> objective,
			MeasuredPerformanceValue<BigDecimal> performanceMeasureValue) {
		
		// second do actual checking
		CPPICheckRules checkRules = new CPPICheckRules();
		checkRules.init(objective, performanceMeasureValue);
		checkRules.applyCheckingRules();
		CPPIDeviation deviation = new CPPIDeviation(new BigDecimal(checkRules.getCushion()));
		cppiValues.setCushion(deviation.getValue().doubleValue());
		
		return deviation;
	}
	
	public Deviation<BigDecimal> check() {
		
		Double xrprev = cppiValues.getPartRiskyAssetPrev();
		Double xfprev = cppiValues.getPartRisklessAssetPrev();
		Double scurrent = cppiValues.getStockPriceNow();
		Double sprev = cppiValues.getStockPriceLastPeriod();
		Double r = cppiValues.getConf().getR();
		Double i = cppiValues.getConf().getTimeHorizon();
		Double wealth = cppiValues.getConf().getInvestement();
		
		// first do measuring
		CPPIMeasureRules measureRules = new CPPIMeasureRules();
		measureRules.init(r, i, scurrent, sprev, xrprev, xfprev, wealth);
		MeasuredPerformanceValue<BigDecimal> performance = measureRules.measure();
		
		// set the measured values to the cppi object
		cppiValues.setTsr(measureRules.getResultTSR());
		cppiValues.setWealth(measureRules.getResultWealth());
		
		return getCheckResult(objective, performance);
	}
	
	public CPPIValues getCppiValues() {
		return cppiValues;
	}

	public void setCppiValues(CPPIValues cppiValues) {
		this.cppiValues = cppiValues;
	}

	public ObjectiveSetting<BigDecimal> getObjective() {
		return objective;
	}

	public void setObjective(ObjectiveSetting<BigDecimal> objective) {
		this.objective = objective;
	}
}
