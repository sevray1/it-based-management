import requests


def get_current():
    url = 'http://localhost:8080/rest/data/cppi/itbmdevs/current'
    params = None
    r = requests.get(url, params=params)
    currentcppi = r.json()
    return {'currentcppi': currentcppi}


def get_history():
    url = 'http://localhost:8080/rest/data/cppi/itbmdevs/history'
    params = None
    r = requests.get(url, params=params)
    historycppi = r.json()
    return {'historycppi': historycppi}


def plan(data):
    url = 'http://localhost:8080/rest/data/cppi/conf'
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    requests.post(url, data, headers=headers)
