from django.conf.urls import url

from . import views

# frontend

urlpatterns = [
    url(r'^$', views.index, name='index'),
]
