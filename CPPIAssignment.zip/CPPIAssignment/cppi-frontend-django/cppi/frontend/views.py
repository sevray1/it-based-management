from django.shortcuts import render
from django.http import HttpResponse
from django.contrib import messages
import json

from frontend.models import CppiValues
from .forms import CppiPlanConfigurationForm
from .models import CppiPlanConfiguration

import frontend.services

# Create your views here.
def test(request):
    return HttpResponse("Hello, world. You're at the polls index.")

def index(request):
    if request.method == "POST":
        form = CppiPlanConfigurationForm(request.POST)
        if form.is_valid():
            cppiportfolio = form.save(commit=False)

            context = {'portfolio': cppiportfolio,  'form': form}
            
            messages.success(request, "Portfolio saved. Start the StockPriceSystem now!")
            frontend.services.plan(json.dumps(cppiportfolio.getDictionary()))

            return render(request, 'frontend/index.html', context)
    else:
        form = CppiPlanConfigurationForm()

        # current
        cppijson = frontend.services.get_current()

        if 'exception' in cppijson['currentcppi']:
            return render(request, 'frontend/index.html', {'form': form})

        cppicurrent = CppiValues()
        cppicurrent.jsonToClass(cppijson['currentcppi'])

        # history
        list = []
        cppijson = frontend.services.get_history()
        for cppidict in cppijson['historycppi']:
            cppihistory = CppiValues()
            cppihistory.jsonToClass(cppidict)
            list.append(cppihistory)

        return render(request, 'frontend/index.html', {'form': form, 'cppi': cppicurrent, 'cppihistory': list})

