from django.db import models
from decimal import Decimal

# Create your models here.
class CppiPlanConfiguration(models.Model):
    floor = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('100.00'))
    riskappetite = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('2.00'))
    maxriskfraction = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('0.90'))
    investement = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('100.00'))
    timehorizon = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('365'))
    account = models.CharField(max_length=20, default="itbmdevs")
    r = models.DecimalField(max_digits=5, decimal_places=2, default=Decimal('0.05'))

    def getDictionary(self):
        data = {}
        data['floorObjective'] = '{}'.format(self.floor)
        data['riskAppetite'] = '{}'.format(self.riskappetite)
        data['maxRiskFraction'] = '{}'.format(self.maxriskfraction)
        data['investement'] = '{}'.format(self.investement)
        data['timeHorizon'] = '{}'.format(self.timehorizon)
        data['account'] = '{}'.format(self.account)
        return data

class CppiValues(models.Model):
    t = models.IntegerField()
    ttt = models.DecimalField(max_digits=5, decimal_places=2)
    ft = models.DecimalField(max_digits=5, decimal_places=2)
    ct = models.DecimalField(max_digits=5, decimal_places=2)
    xrt = models.DecimalField(max_digits=5, decimal_places=2)
    xft = models.DecimalField(max_digits=5, decimal_places=2)
    st = models.DecimalField(max_digits=5, decimal_places=2)
    tsrt = models.DecimalField(max_digits=5, decimal_places=2)
    wt = models.DecimalField(max_digits=5, decimal_places=2)
    account = models.CharField(max_length=20)

    def jsonToClass(self, aux):
        self.t = aux['t']
        self.ttt = aux['ttt']
        self.ft = aux['ft']
        self.ct = aux['ct']
        self.xrt = aux['xrt']
        self.xft = aux['xft']
        self.st = aux['st']
        self.tsrt = aux['tsrt']
        self.wt = aux['wt']
        self.account = aux['account']

