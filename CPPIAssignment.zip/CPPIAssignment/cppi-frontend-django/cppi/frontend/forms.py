from django import forms
from .models import CppiPlanConfiguration

class CppiPlanConfigurationForm(forms.ModelForm):
    class Meta:
        model = CppiPlanConfiguration
        fields = '__all__'
