package tu.wien.itbm.assignment1.cppi_essentials.model.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import tu.wien.itbm.assignment1.cppi_essentials.model.CPPIValues;

@Entity
public class CPPIValuesDTO {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	private String t; // 1,2,3,4,5,6....
	private String ttt;
	private String ft;
	private String ct;
	private String xrt;
	private String xft;
	private String st;
	private String tsrt;
	private String wt;
	private String account;
	
	public CPPIValuesDTO() {}
	
	public CPPIValuesDTO(CPPIValues values) {
		this.t = ""+values.getPeriod().intValue();
		this.ttt = String.format( "%.4f", values.getTTT());
		this.ft = String.format( "%.4f", values.getFloorObjective_t());
		this.ct = String.format( "%.4f", values.getCushion());
		this.xrt = String.format( "%.4f", values.getPartRiskyAsset());
		this.xft = String.format( "%.4f", values.getPartRisklessAsset());
		this.st = String.format( "%s", values.getStockPriceNow());
		this.tsrt = String.format( "%.4f", values.getTsr());
		this.wt = String.format( "%.4f", values.getWealth());
		this.setAccount(values.getConf().getAccount());
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getT() {
		return t;
	}

	public void setT(String t) {
		this.t = t;
	}

	public String getTtt() {
		return ttt;
	}

	public void setTtt(String ttt) {
		this.ttt = ttt;
	}

	public String getFt() {
		return ft;
	}

	public void setFt(String ft) {
		this.ft = ft;
	}

	public String getCt() {
		return ct;
	}

	public void setCt(String ct) {
		this.ct = ct;
	}

	public String getXrt() {
		return xrt;
	}

	public void setXrt(String xrt) {
		this.xrt = xrt;
	}

	public String getXft() {
		return xft;
	}

	public void setXft(String xft) {
		this.xft = xft;
	}

	public String getSt() {
		return st;
	}

	public void setSt(String st) {
		this.st = st;
	}

	public String getTsrt() {
		return tsrt;
	}

	public void setTsrt(String tsrt) {
		this.tsrt = tsrt;
	}

	public String getWt() {
		return wt;
	}

	public void setWt(String wt) {
		this.wt = wt;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

}
