package tu.wien.itbm.assignment1.cppi_essentials.controller;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class Runner implements CommandLineRunner {

    private final RabbitTemplate rabbitTemplate;
    private final CPPIDataServiceAsync receiver;
    private final ConfigurableApplicationContext context;

    public Runner(CPPIDataServiceAsync receiver, RabbitTemplate rabbitTemplate,
            ConfigurableApplicationContext context) {
        this.receiver = receiver;
        this.rabbitTemplate = rabbitTemplate;
        this.context = context;
    }

    public void run(String... args) throws Exception {
//        System.out.println("Sending message...");
//        
//        ObjectMapper mapper = new ObjectMapper();
//        CPPIData cppidata = new CPPIData("a", "b");
//        StockPriceData stockdata = new StockPriceData(111.1);
//        
//        MessageDTO messageCPPI = new MessageDTO(CPPIData.class.getSimpleName(), mapper.writeValueAsString(cppidata));
//        MessageDTO messageSTOCK = new MessageDTO(StockPriceData.class.getSimpleName(), mapper.writeValueAsString(stockdata));
//                
//        //Object to JSON in String
//        String jsonInString = mapper.writeValueAsString(messageCPPI);
//        rabbitTemplate.convertAndSend(Application.queueName, jsonInString);
//        
//        jsonInString = mapper.writeValueAsString(messageSTOCK);
//        rabbitTemplate.convertAndSend(Application.queueName, jsonInString);
        
        /******
         * 
         */
        
//        CPPIPortfolioConfigurationDTO conf = new CPPIPortfolioConfigurationDTO();
//		conf.setFloorObjective(100d);
//		conf.setTimeHorizon(365d);
//		conf.setInvestement(100d);
//		conf.setMaxRiskFraction(0.9d);
//		conf.setRiskAppetite(2d);
//		conf.setAccount("itbm-devs");
//        
//		ObjectMapper mapper = new ObjectMapper();
//	    String jsonInString = mapper.writeValueAsString(conf);
//	    System.out.println(jsonInString);
		
        // stops the whole application
//        context.close();
    }

}