package tu.wien.itbm.assignment1.cppi_essentials.model;

import java.text.DecimalFormat;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class CPPIValues {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	@OneToOne
	@JoinColumn(name="portfolioId")
	private CPPIPortfolioConfiguration conf;

	private Double floorObjective_t;
	private Double tsr; // total shareholder return
	private Double cushion; // Ct
	private Double partRiskyAsset; // Xr,t
	private Double partRisklessAsset; // Xf,t
	private Double partRiskyAssetPrev; // Xr,t-1
	private Double partRisklessAssetPrev; // Xf,t-1
	private Double stockPriceLastPeriod; // St-1
	private Double stockPriceNow; // St
	private Double wealth; // Wt

	private Double period; // 1,2,3,4,5,6....

	public CPPIValues() {}
	
	@JsonIgnore
	@Transient
	public Double getTTT() {
		return new Double(1) - period / conf.getTimeHorizon();
	}
	
	@JsonIgnore
	@Transient
	public String printHeader() {
		return String.format("%s\n|%4s|%7s|%10s|%7s|%10s|%10s|%10s|%7s|%10s|\n%s",
				"-----------------------------------------------------------------------------------",
				"t", "TtT", "Ft", "Ct", "Xr,t", "Xf,t", "St", "TSRt", "Wt",
				"-----------------------------------------------------------------------------------"
				);
	}
	
	@JsonIgnore
	@Transient
	public String toString() {
		DecimalFormat df = new DecimalFormat("#.0000"); 
		return String.format("%4s|%7s|%10s|%7s|%10s|%10s|%10s|%7s|%10s", 
				period, 
				df.format(getTTT()), 
				df.format(floorObjective_t), 
				df.format(cushion), 
				df.format(partRiskyAsset), 
				df.format(partRisklessAsset), 
				df.format(stockPriceNow), 
				df.format(tsr), 
				df.format(wealth)
		);
	}
	
	@JsonIgnore
	@Transient
	public void correctAssets() {
		// set risk free
		setPartRisklessAssetPrev(getPartRisklessAsset());
		setPartRisklessAsset(null); // will be calcualted in act
		// set risky
		setPartRiskyAssetPrev(getPartRiskyAsset());
		setPartRiskyAsset(null); // will be calculated in act
		
//		System.out.println(String.format("Xrt: %s, Xrt-prev: %s", getPartRiskyAsset(), getPartRiskyAssetPrev()));
//		System.out.println(String.format("Xft: %s, Xft-prev: %s", getPartRisklessAsset(), getPartRisklessAssetPrev()));
	}
	
	@JsonIgnore
	@Transient
	public void adjustStock(Double stockprice) {
		setStockPriceLastPeriod(getStockPriceNow());
		setStockPriceNow(stockprice);
	}	

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public CPPIPortfolioConfiguration getConf() {
		return conf;
	}

	public void setConf(CPPIPortfolioConfiguration conf) {
		this.conf = conf;
	}

	public Double getFloorObjective_t() {
		return floorObjective_t;
	}

	public void setFloorObjective_t(Double floorObjective_t) {
		this.floorObjective_t = floorObjective_t;
	}

	public Double getTsr() {
		return tsr;
	}

	public void setTsr(Double tsr) {
		this.tsr = tsr;
	}

	public Double getCushion() {
		return cushion;
	}

	public void setCushion(Double cushion) {
		this.cushion = cushion;
	}

	public Double getPartRiskyAsset() {
		return partRiskyAsset;
	}

	public void setPartRiskyAsset(Double partRiskyAsset) {
		this.partRiskyAsset = partRiskyAsset;
	}

	public Double getPartRisklessAsset() {
		return partRisklessAsset;
	}

	public void setPartRisklessAsset(Double partRisklessAsset) {
		this.partRisklessAsset = partRisklessAsset;
	}

	public Double getStockPriceLastPeriod() {
		return stockPriceLastPeriod;
	}

	public void setStockPriceLastPeriod(Double stockPriceLastPeriod) {
		this.stockPriceLastPeriod = stockPriceLastPeriod;
	}

	public Double getStockPriceNow() {
		return stockPriceNow;
	}

	public void setStockPriceNow(Double stockPriceNow) {
		this.stockPriceNow = stockPriceNow;
	}

	public Double getWealth() {
		return wealth;
	}

	public void setWealth(Double wealth) {
		this.wealth = wealth;
	}

	public Double getPeriod() {
		return period;
	}

	public void setPeriod(Double period) {
		this.period = period;
	}

	public Double getPartRiskyAssetPrev() {
		return partRiskyAssetPrev;
	}

	public void setPartRiskyAssetPrev(Double partRiskyAssetPrev) {
		this.partRiskyAssetPrev = partRiskyAssetPrev;
	}

	public Double getPartRisklessAssetPrev() {
		return partRisklessAssetPrev;
	}

	public void setPartRisklessAssetPrev(Double partRisklessAssetPrev) {
		this.partRisklessAssetPrev = partRisklessAssetPrev;
	}
}
