package tu.wien.itbm.assignment1.cppi_essentials.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tu.wien.itbm.assignment1.cppi_essentials.database.CPPIPortfolioRepository;
import tu.wien.itbm.assignment1.cppi_essentials.database.CPPIValueHistoryRepository;
import tu.wien.itbm.assignment1.cppi_essentials.database.CPPIValueRepository;
import tu.wien.itbm.assignment1.cppi_essentials.model.CPPIPortfolioConfiguration;
import tu.wien.itbm.assignment1.cppi_essentials.model.CPPIValues;
import tu.wien.itbm.assignment1.cppi_essentials.model.dto.CPPIPortfolioConfigurationDTO;
import tu.wien.itbm.assignment1.cppi_essentials.model.dto.CPPIValuesDTO;


@RestController
@RequestMapping(value = "/rest/data")
public class CPPIDataServiceSync {
	
	private static final String COMPONENT_NAME = "CPPIDataService";

	@Autowired
	private CPPIValueRepository cppiRepo;
	
	@Autowired
	private CPPIPortfolioRepository portfolioRepo;
	
	@Autowired
	private CPPIValueHistoryRepository historyRepo;
	
	/**
	 * Takes the user input and persists it. (synchronous, simple restful ws)
	 * @return
	 */
	@RequestMapping(value = "/cppi/conf", method = RequestMethod.POST)
	public void UserDataService(@RequestBody CPPIPortfolioConfigurationDTO configuration) {
		
		// the values given by the user (planning configuration) will be persisted here
		System.out.println("portfolio retrieved.");
		
		CPPIValues cppiValues = new CPPIValues();
		CPPIPortfolioConfiguration conf = new CPPIPortfolioConfiguration(configuration);
		portfolioRepo.save(conf);
		
		List<CPPIPortfolioConfiguration> list = (List<CPPIPortfolioConfiguration>) portfolioRepo.findAll();
		System.out.println(list.size());
		
		cppiValues.setConf(conf);
		cppiValues = cppiRepo.save(cppiValues);
		
		System.out.println(String.format( "Portfolio [id=%d] for user [account=%s] saved.", cppiValues.getId(), cppiValues.getConf().getAccount()));
	}
	
	@RequestMapping(value = "/cppi/{account}/current", method = RequestMethod.GET)
	public CPPIValuesDTO getCurrent(@PathVariable String account) {
		CPPIPortfolioConfiguration conf = portfolioRepo.findByAccount(account);
		CPPIValues cppiValues = cppiRepo.findByConf(conf);
		
		// returns current values
		return new CPPIValuesDTO(cppiValues);
	}
	
	@RequestMapping(value = "/cppi/{account}/history", method = RequestMethod.GET)
	public List<CPPIValuesDTO> getHistory(@PathVariable String account) {
		return historyRepo.findAllByAccount(account);
	}
	
	/**
	 * After cppi values were optimized, this service is called to persist them
	 * 
	 * @return
	 */
	@RequestMapping(value = "/cppi/update", method = RequestMethod.POST)
	public void CPPIValuesUpdate(@RequestBody CPPIValues cppiValues) {
//		System.out.println("optimized values retrieved.");
		cppiValues = cppiRepo.save(cppiValues);
		
		// used for history values instead of auditing with envers
		CPPIValuesDTO dto = new CPPIValuesDTO(cppiValues); 
		historyRepo.save(dto);
		
//		System.out.println(String.format( "CPPI values [id=%d] updated.", cppiValues.getId()));
		System.out.println(cppiValues.toString());
	}
}
