package tu.wien.itbm.assignment1.cppi_essentials.database;

import org.springframework.data.repository.CrudRepository;

import tu.wien.itbm.assignment1.cppi_essentials.model.CPPIPortfolioConfiguration;

public interface CPPIPortfolioRepository extends CrudRepository<CPPIPortfolioConfiguration, Long> {

    CPPIPortfolioConfiguration findByAccount(String account);
    
}