package tu.wien.itbm.assignment1.cppi_essentials.controller;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import tu.wien.itbm.assignment1.cppi_essentials.database.CPPIPortfolioRepository;
import tu.wien.itbm.assignment1.cppi_essentials.database.CPPIValueRepository;
import tu.wien.itbm.assignment1.cppi_essentials.model.CPPIPortfolioConfiguration;
import tu.wien.itbm.assignment1.cppi_essentials.model.CPPIValues;
import tu.wien.itbm.assignment1.cppi_essentials.model.dto.StockPriceData;

@Component
public class CPPIDataServiceAsync {

	@Autowired
	private CPPIValueRepository cppiRepo;
	@Autowired
	private CPPIPortfolioRepository cppiPortfolio;
	@Autowired
    private RabbitTemplate rabbitTemplate;

	public void receive(byte[] message) {
		handleMessage(new String(message));
	}

	public void receive(String message) {
		StopWatch watch = new StopWatch();
		watch.start();

		handleMessage(message);

		watch.stop();
		System.out.println("Done processing in " + watch.getTotalTimeSeconds() + "s");
	}

	public void handleMessage(String objectJson) {
//		System.out.println("Received <" + objectJson + ">");

		try {
			ObjectMapper mapper = new ObjectMapper();
			StockPriceData stock = mapper.readValue(objectJson, StockPriceData.class);
			stockPriceUpdate(stock);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

	private void stockPriceUpdate(StockPriceData stockData) throws JsonProcessingException {

		// get cppi values object
		CPPIPortfolioConfiguration portfolioConfiguration = cppiPortfolio.findByAccount("itbmdevs");
		CPPIValues cppiValues = cppiRepo.findByConf(portfolioConfiguration);

		// adjust the stock price (set St and St-1)
		cppiValues.adjustStock(stockData.getPrice());

		// call optimization interface of CPPIStrategy
		ObjectMapper mapper = new ObjectMapper();
		String jsonInString = mapper.writeValueAsString(cppiValues);

		jsonInString = mapper.writeValueAsString(cppiValues);
		rabbitTemplate.convertAndSend("cppi-strategy-queue", jsonInString);

//		System.out.println(String.format("Sent CPPIValues [id=%d] from User [name=%s]", cppiValues.getId(),
//				cppiValues.getConf().getAccount()));
	}

}
