package tu.wien.itbm.assignment1.cppi_financial_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {

	// Important: Controllers must be in the same or a sub folder
	// 				in order to be found and published
	
    public static void main(String[] args) {
    	System.out.println( "Initiate and Start the Investment System." );
        SpringApplication.run(Application.class, args);
    }
}
