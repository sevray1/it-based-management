package tu.wien.itbm.assignment1.cppi_financial_system.controller;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import tu.wien.itbm.assignment1.cppi_financial_system.model.InvestmentInfoDTO;

/**
 * This represents a simple rest interface offering only one service which logs to stdout
 * 
 * (The Stock Price System is implemented using Python as separate component)
 * 
 * java -jar target/cppi-financial-system-0.0.1-SNAPSHOT.jar --server.port=8090
 * 
 * @author itbm-devs
 */
@RestController
@RequestMapping(value = "/rest")
public class InvestmentSystem {

	private static final String COMPONENT_NAME = "InvestmentSystem";

	// For Testing: use a rest client (i.e chrome rest client) and send
	// url: http://localhost:8090/rest/invest
	// method: POST
	// Content-Type: application/json
	// raw payload: {"account":"testaccount","portfolioId":1,"risky": 99.0,"riskless":0.1}

	@RequestMapping(value = "/invest", method = RequestMethod.POST)
	public void invest(@RequestBody InvestmentInfoDTO data) {
		String log = String.format("[%s]: Investment for [%s], portfolio [id=%d] received: risky=%s, riskless=%s", 
				COMPONENT_NAME,
				data.getAccount(),
				data.getPortfolioId(),
				data.getRisky(),
				data.getRiskless());
		
		System.out.println(log);
	}
}